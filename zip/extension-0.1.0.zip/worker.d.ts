import TLSN from './tlsn';
export default TLSN;
//# sourceMappingURL=worker.d.ts.map